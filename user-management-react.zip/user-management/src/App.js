import React, { useState, useEffect } from 'react';
import UserList from './components/UserList';
import './App.css'; 

const App = () => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/users')
      .then((response) => response.json())
      .then((data) => {
        setUsers(data);
        setLoading(false);
      })
      .catch((err) => console.error('Error fetching users:', err));
  }, []);

  const handleLikeDislike = (id) => {
    setUsers(
      users.map((user) =>
        user.id === id ? { ...user, liked: !user.liked } : user
      )
    );
  };

  const handleDelete = (id) => {
    setUsers(users.filter((user) => user.id !== id));
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="App">
      <UserList
        users={users}
        onLikeDislike={handleLikeDislike}
        onDelete={handleDelete}
      />
    </div>
  );
};

export default App;
