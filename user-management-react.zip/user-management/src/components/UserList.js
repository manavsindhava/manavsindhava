import React from 'react';

const UserList = ({ users, onLikeDislike, onDelete }) => {
  return (
    <div>
      <h1>User List</h1>
      <ul>
        {users.map((user) => (
          <li key={user.id} className="user-card">
            <div>
              <img
                src={`https://avatars.dicebear.com/v2/avataaars/${user.username}.svg?options[mood][]=happy`}
                alt={user.username}
                width="50"
                height="50"
              />
              <span>{user.name}</span>
              <p>{user.email}</p>

              <button
                onClick={() => onLikeDislike(user.id)}
                className={user.liked ? 'liked' : ''}
              >
                {user.liked ? 'Dislike' : 'Like'}
              </button>

              <button onClick={() => onDelete(user.id)}>Delete</button>
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserList;
