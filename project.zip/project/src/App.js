import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './components/HomePage';
import AboutUs from './components/AboutUs';
import Service from './components/Service';
import Team from './components/Team';
import Client from './components/Client';
import ContactUs from './components/ContactUs';
import Footer from './components/Footer';
function App() {
  return (
    <Router>
      <Routes>
        <Route exact path="/" element={<HomePage />} />
        <Route exact path="/about" element={<AboutUs />} />
        <Route exact path="/service" element={<Service />} />
        <Route exact path="/team" element={<Team />} />
        <Route exact path="/client" element={<Client />} />
        <Route exact path="/contact" element={<ContactUs />} />
        <Route exact path="/footer" element={<Footer />} />
      </Routes>
    </Router>
  );
}

export default App;
