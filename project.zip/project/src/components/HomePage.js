import React from 'react';
import Navbar from './Navbar';
import img1 from '../images/image1.jpg'
import "./HomePage.css";
import AboutUs from './AboutUs';
import Service from './Service';
import Team from './Team';
import Client from './Client';
import ContactUs from './ContactUs';
import Footer from './Footer';

const HomePage = () => {
  return (
    <div>
      <Navbar/>
    <div className="homepage-container">
      <div className="homepage-image">
        <img src={img1} alt="Decorative Scene" />
      </div>

      <div className="homepage-content">
        <h1>Welcome to Mendleson</h1>
        <p>
          At Mendleson, we believe in providing the best services to our clients. 
          Our expertise lies in delivering high-quality solutions tailored to your needs. 
          Explore our range of services and let us help you achieve your goals.
        </p>
      </div>
    </div>
    <div>
      <AboutUs/>
      <Service/>
      <Team/>
      <Client/>
      <ContactUs/>
      <Footer/>
    </div>
    </div>
  );
};


export default HomePage;
