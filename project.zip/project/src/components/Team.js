import React from "react";
import "./Team.css";
import Navbar from "./Navbar";

const Team = () => {
  return (
    <div>
        <Navbar/>
    <div className="team-container">
      <section className="team-section">
        <h2>Our Team</h2>
        <div className="team-members">
          <div className="team-member">
            <img src="/images/img5.jpeg" alt="Jessica D'suza" />
            <h4>Jessica D'suza</h4>
          </div>
          <div className="team-member">
            <img src="/images/img6.jpeg" alt="Johny Williams" />
            <h4>Johny Williams</h4>
          </div>
          <div className="team-member">
            <img src="/images/img7.jpeg" alt="Sanya R." />
            <h4>Sanya R.</h4>
          </div>
        </div>
      </section>
    </div>
    </div>
  );
};

export default Team;
