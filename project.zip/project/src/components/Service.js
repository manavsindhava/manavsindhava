import React from "react";
import "./Service.css";
import Navbar from "./Navbar";

const Service = () => {
  const services = [
    {
      title: "Engagement",
      description:
        "We love what we do and are driven by achieving great results for our clients. Our awards and impressive client list are testament to our high-quality approach. We deliver value, creativity, results, and exceptional levels of customer service and professionalism. We specialize in infrastructure development, energy, and natural resources.",
      image: "/images/img1.jpeg", 
    },
    {
      title: "Communications",
      description:
        "Our communication strategies are designed to effectively convey messages and achieve impactful results. We focus on collaboration and tailoring messages to resonate with the audience.",
      image: "/images/img2.jpeg",
    },
    {
        title: "Consultation and Research",
        description:"We love what we do and are driven by achieving great results for our clients. Our awards and impressive client list are testament to our high-quality approach. We deliver value, creativity, results, and exceptional levels of customer service and professionalism. We specialize in infrastructure development, energy, and natural resources.",
        image: "/images/img3.jpeg",
    },
    {
        title: "Training & Mentoring",
        description:"We love what we do and are driven by achieving great results for our clients. Our awards and impressive client list are testament to our high-quality approach. We deliver value, creativity, results, and exceptional levels of customer service and professionalism. We specialize in infrastructure development, energy, and natural resources.",
        image: "/images/img4.jpeg",
    }
    
  
  ];

  return (
    <div>
        <Navbar/>
    <div className="service-container">
      <h1 className="service-header">Services</h1>
      <div className="service-items">
        {services.map((service, index) => (
          <div key={index} className="service-item">
            <div className="service-description">
              <h2>{service.title}</h2>
              <p>{service.description}</p>
            </div>
            <div className="service-image">
              <img src={service.image} alt={service.title} />
            </div>
          </div>
        ))}
      </div>
    </div>
    </div>
  );
};

export default Service;
