import React from "react";
import "./Client.css";
import Navbar from "./Navbar";

const Client = () => {
  const clients = [
    { id: 1, name: "Glycon", logo: "/images/c1.png" },
    { id: 2, name: "Hexatech", logo: "/images/c2.jpeg" },
    { id: 3, name: "NetDev", logo: "/images/c3.png" },
    { id: 4, name: "Level Crossing Removal Authority", logo: "/images/c4.jpeg" },
    { id: 5, name: "BHP", logo: "/images/c1.png" },
    { id: 6, name: "Victoria State Government", logo: "/images/c6.jpeg" },
    { id: 7, name: "Pacific Hydro", logo: "/images/c5.png" },
    { id: 8, name: "Hexatech", logo: "/images/c2.jpeg" },
    { id: 9, name: "Glycon", logo: "/images/c1.png" },
  ];

  return (
    <div>
      <Navbar/>
    <div className="client-container">
      <h2>Our Clients</h2>
      <div className="client-logos">
        {clients.map((client) => (
          <div key={client.id} className="client-logo">
            <img src={client.logo} alt={client.name} />
          </div>
        ))}
      </div>
    </div>
    </div>
  );
};

export default Client;
