// src/components/AboutUs.js
import React from "react";
import "./AboutUs.css";
import Navbar from "./Navbar";

const AboutUs = () => {
  return (
    <div>
        <Navbar/>
    <div className="aboutus-container">
      <div className="aboutus-content">
        <h1>About Mendleson</h1>
        <p>
          Mendleson is a leading company in the industry, offering tailored solutions
          for a wide range of clients. Our team of experts is committed to delivering
          top-notch services that exceed expectations. We believe in continuous innovation
          and a client-first approach, ensuring that our solutions are always aligned with
          your goals.
        </p>
        <p>
          Our journey began with a vision to transform the industry through cutting-edge
          technology and unparalleled customer service. Today, we are proud to serve clients
          worldwide and continue to grow and innovate in the ever-evolving market.
        </p>
        <p>
          At Mendleson, we value integrity, trust, and collaboration. Our team works closely
          with you to understand your unique challenges and craft solutions that help you
          succeed. Let us be your partner in growth!
        </p>
      </div>
    </div>
    </div>
  );
};

export default AboutUs;
